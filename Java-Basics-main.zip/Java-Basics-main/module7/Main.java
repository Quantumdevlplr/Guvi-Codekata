public class Main {
    public static void main(String args[]){

        int i = 5;

        do{
            System.out.println("Hello javac!");
            i++;

        }while(i<=4);
    }
    
}
