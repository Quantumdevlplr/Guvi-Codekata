public class Main
{
    public static void main(String args[])
    {
        int x =15;
        int y =15;
        if (x > y){
            System.out.println(false);
        }
        else if (x < y) {
            System.out.println(true);
        }

        else {
            System.out.println("x is equal to y");
        }
    }
}