public class Main{
    public static void main(String args[]){
        
        for(int i = 4; i <= 0; i--){
            System.out.println("Hello");

        }

    }

}